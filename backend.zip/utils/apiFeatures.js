product = require("../models/product");
class APIFeatures {

    constructor(query, queryStr) {
        this.query = query;
        this.queryStr = queryStr;
    }
    // http://localhost:2173?keyword=apple&price[]
    // http://localhost:4000/api/v1/products?page=1&keyword=apple&price[lte]=1000&price[gte]=10
    search() {
        const keyword = this.queryStr.keyword ? {
            name: {
                $regex: this.queryStr.keyword,
                $options: 'i'
            }
        } : {}
        console.log(this.query, this.queryStr);
        this.query = this.query.find({ ...keyword });
        return this;
    }

    filter() {
        // { 'price[gte]': '100', 'price[lte]': '1000' }
        const queryCopy = { ...this.queryStr };
        // console.log(queryCopy);
        // Removing fields from the query
        const removeFields = ['keyword', 'page']
        removeFields.forEach(el => delete queryCopy[el]);

        let priceFilter = {};
        if (queryCopy['price[gte]'] || queryCopy['price[lte]']) {
            priceFilter.price = {};
            if (queryCopy['price[gte]']) {
                priceFilter.price.$gte = Number(queryCopy['price[gte]']);
            }
            if (queryCopy['price[lte]']) {
                priceFilter.price.$lte = Number(queryCopy['price[lte]']);
            }
            // priceFilter {
            //     price: {
            //         $gte: 100,
            //         $lte: 1000
            //     }
            // }
            delete queryCopy['price[gte]'];
            delete queryCopy['price[lte]'];
        }

        // ratings filter: ?ratings[gte]=4  ->  products whose average rating is 4 or higher
        const minRating = Number(queryCopy['ratings[gte]']);
        if (minRating > 0) {
            priceFilter.ratings = { $gte: Math.min(minRating, 5) };
        }

        // review filter: ?numOfReviews[gte]=5  ->  products with at least 5 reviews
        const minReviews = Number(queryCopy['numOfReviews[gte]']);
        if (minReviews > 0) {
            priceFilter.numOfReviews = { $gte: minReviews };
        }

        // category filter: ?category=Lenses  ->  exact match on the product category
        if (typeof queryCopy.category === 'string' && queryCopy.category.trim()) {
            priceFilter.category = queryCopy.category.trim();
        }

        this.query = this.query.find(priceFilter);
        return this;
    }

    pagination(resPerPage) {
        const currentPage = Number(this.queryStr.page) || 1;
        const skip = resPerPage * (currentPage - 1);

        this.query = this.query.limit(resPerPage).skip(skip);
        return this;
    }
}
module.exports = APIFeatures;