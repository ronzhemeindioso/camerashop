const mongoose = require('mongoose')

const orderSchema = mongoose.Schema({
    shippingInfo: {
        address: {
            type: String,
            required: true
        },
        city: {
            type: String,
            required: true
        },
        phoneNo: {
            type: String,
            required: true
        },
        postalCode: {
            type: String,
            required: true
        },
        country: {
            type: String,
            required: true
        }
    },
    user: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'User'
    },
    orderItems: [
        {
            name: {
                type: String,
                required: true
            },
            quantity: {
                type: Number,
                required: true
            },
            image: {
                type: String,
                required: true
            },
            price: {
                type: Number,
                required: true
            },
            product: {
                type: mongoose.Schema.Types.ObjectId,
                required: true,
                ref: 'Product'
            }
        }
    ],
    // voucher applied at checkout (the discount is already taken off totalPrice)
    voucher: {
        _id: false,
        code: { type: String },
        discountType: { type: String },
        discountValue: { type: Number }
    },
    discountPrice: {
        type: Number,
        default: 0.0
    },
    paymentInfo: {
        id: {
            type: String
        },
        status: {
            type: String
        }
    },
    paidAt: {
        type: Date
    },

    itemsPrice: {
        type: Number,
        required: true,
        default: 0.0
    },
    taxPrice: {
        type: Number,
        required: true,
        default: 0.0
    },
    shippingPrice: {
        type: Number,
        required: true,
        default: 0.0
    },
    totalPrice: {
        type: Number,
        required: true,
        default: 0.0
    },
    orderStatus: {
        type: String,
        required: true,
        default: 'Processing'
    },
    deliveredAt: {
        type: Date
    },
    // optional courier tracking number, entered when the order is marked as shipped
    trackingNumber: {
        type: String,
        trim: true,
        maxLength: [100, 'Tracking number cannot exceed 100 characters']
    },
    // when each status was reached (shown under the progress steps on the admin order page)
    statusHistory: [
        {
            _id: false,
            status: { type: String, required: true },
            at: { type: Date, default: Date.now }
        }
    ],
    // true once the ordered quantities have been taken out of stock (so it only happens once)
    stockDeducted: {
        type: Boolean,
        default: false
    },
    createdAt: {
        type: Date,
        default: Date.now
    }

})

module.exports = mongoose.model('Order', orderSchema)