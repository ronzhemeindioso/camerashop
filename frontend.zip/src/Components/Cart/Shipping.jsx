import React, { useState } from 'react'
import { useNavigate } from "react-router-dom";
import { countries } from 'countries-list'
import MetaData from '../Layout/MetaData'
import CheckoutSteps from './CheckoutSteps'
import { useDispatch, useSelector } from 'react-redux'
import { saveShippingInfo } from '../../actions/cartActions'
import './checkout.css'

const Shipping = () => {
    const dispatch = useDispatch();
    const { shippingInfo } = useSelector(state => state.cart)
    const { user } = useSelector(state => state.auth)   // details saved in "Set up your profile"
    const countriesList = Object.values(countries)
    const [address, setAddress] = useState(shippingInfo.address || [user?.address, user?.barangay, user?.province].filter(Boolean).join(', '))
    const [city, setCity] = useState(shippingInfo.city || user?.city || '')
    const [postalCode, setPostalCode] = useState(shippingInfo.postalCode || user?.postalCode || '')
    const [phoneNo, setPhoneNo] = useState(shippingInfo.phoneNo || user?.phoneNo || '')
    const [country, setCountry] = useState(shippingInfo.country || user?.country || countriesList[0]?.name || '')
    let navigate = useNavigate();

    const submitHandler = (e) => {
        e.preventDefault()

        dispatch(saveShippingInfo({ address, city, phoneNo, postalCode, country }))
        navigate('/confirm')
    }

    return (
        <>
            <MetaData title={'Shipping Info'} />
            <CheckoutSteps shipping />
            <div className="co-page co-page--narrow">
                <form className="co-card" onSubmit={submitHandler}>
                    <h1 className="co-title">Shipping Information</h1>
                    <p className="co-subtitle">Where should we deliver your order?</p>

                    <div className="co-field">
                        <label className="co-label" htmlFor="address_field">Street address</label>
                        <input
                            type="text"
                            id="address_field"
                            className="co-input"
                            value={address}
                            onChange={(e) => setAddress(e.target.value)}
                            required
                        />
                    </div>

                    <div className="co-row-2">
                        <div className="co-field">
                            <label className="co-label" htmlFor="city_field">City</label>
                            <input
                                type="text"
                                id="city_field"
                                className="co-input"
                                value={city}
                                onChange={(e) => setCity(e.target.value)}
                                required
                            />
                        </div>

                        <div className="co-field">
                            <label className="co-label" htmlFor="postal_code_field">Postal code</label>
                            <input
                                type="number"
                                id="postal_code_field"
                                className="co-input"
                                value={postalCode}
                                onChange={(e) => setPostalCode(e.target.value)}
                                required
                            />
                        </div>
                    </div>

                    <div className="co-field">
                        <label className="co-label" htmlFor="phone_field">Phone number</label>
                        <input
                            type="tel"
                            id="phone_field"
                            className="co-input"
                            value={phoneNo}
                            onChange={(e) => setPhoneNo(e.target.value)}
                            required
                        />
                    </div>

                    <div className="co-field">
                        <label className="co-label" htmlFor="country_field">Country</label>
                        <select
                            id="country_field"
                            className="co-input"
                            value={country}
                            onChange={(e) => setCountry(e.target.value)}
                            required
                        >
                            {countriesList.map(country => (
                                <option key={country.name} value={country.name}>
                                    {country.name}
                                </option>
                            ))}
                        </select>
                    </div>

                    <button
                        id="shipping_btn"
                        type="submit"
                        className="co-btn"
                    >
                        Continue
                    </button>
                </form>
            </div>
        </>
    )
}

export default Shipping
